import ReactDOM from "react-dom";
import React from "react";
import { App } from "./App";

//app that it will be display in html page
ReactDOM.render(<App/>, document.getElementById("app"));